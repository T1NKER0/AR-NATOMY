function changeVal(){
		document.getElementById("demo").innerHTML = "Hello JavaScript!";
	}